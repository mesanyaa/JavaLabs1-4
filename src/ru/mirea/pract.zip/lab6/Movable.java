package ru.mirea.lab6;

public interface Movable {
    public void moveUp(int ySpeed);
    public void moveDown(int ySpeed);
    public void moveLeft(int xSpeed);
    public void moveRight(int xSpeed);
}
