package ru.mirea.lab6;

public interface Convertible {
    double convert(double temperature);
}
