package ru.mirea.lab4;

public enum Category {
    ELECTRONICS,
    CLOTHING,
    BOOKS,
    BEAUTY,
    HOME_APPLIANCES
}

