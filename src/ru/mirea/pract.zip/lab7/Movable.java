package ru.mirea.lab7;

public interface Movable {
    void moveUp();

    void moveDown();

    void moveLeft();

    void moveRight();
}
